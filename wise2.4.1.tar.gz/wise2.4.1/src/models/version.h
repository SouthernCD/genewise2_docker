

#define VERSION_NUMBER "$Name: wise2-4-1 $"
#define RELEASE_DAY    "unreleased"
#define COMPILE_DATE   __DATE__   

